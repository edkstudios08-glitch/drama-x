// 1. Instalar dependencias primero abriendo la terminal y escribiendo:
// npm install firebase-admin

const admin = require('firebase-admin');

// 2. Debes descargar tu clave privada de Firebase (serviceAccountKey.json)
// Ve a Firebase Console -> Configuración del proyecto -> Cuentas de servicio -> Generar nueva clave privada.
// Guarda ese archivo JSON en la misma carpeta que este script y ponle el nombre 'serviceAccountKey.json'
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// --- CONFIGURACIÓN DE TU APP ---
const APP_ID = 'drama-x-prod';
const COMMON_PASSWORD = 'SoyUnUsuarioFalso123'; // La contraseña que tendrán todos
const USERS_TO_CREATE = 5000; // Cambia este número a los que quieras crear (Cuidado con el límite de 20.000/día gratis)

// Listas para generar nombres aleatorios
const nombres = ['juan', 'maria', 'carlos', 'ana', 'luis', 'laura', 'pedro', 'lucia', 'david', 'sofia', 'pablo', 'elena', 'diego', 'carmen', 'jorge', 'alba'];
const apellidos = ['perez', 'gomez', 'lopez', 'garcia', 'fernandez', 'martinez', 'sanchez', 'rodriguez', 'martinez', 'diaz'];
const adjetivos = ['pro', 'gamer', 'real', 'oficial', 'vip', 'drama', 'king', 'queen'];

// Función para generar un usuario aleatorio
function generarUsuarioAleatorio() {
    const nombre = nombres[Math.floor(Math.random() * nombres.length)];
    const apellido = apellidos[Math.floor(Math.random() * apellidos.length)];
    const adjetivo = adjetivos[Math.floor(Math.random() * adjetivos.length)];
    const numero = Math.floor(Math.random() * 9999);
    
    // Generar formatos variados: juan_perez, mariagamer_99, carlos_oficial, etc.
    const formatos = [
        `${nombre}_${apellido}`,
        `${nombre}${adjetivo}_${numero}`,
        `${nombre}_${numero}`,
        `${adjetivo}_${apellido}`,
        `${nombre}_${apellido}_${numero}`
    ];
    
    const username = formatos[Math.floor(Math.random() * formatos.length)] + Math.floor(Math.random() * 100); // Añadimos un número final para evitar duplicados
    const displayName = nombre.charAt(0).toUpperCase() + nombre.slice(1) + " " + apellido.charAt(0).toUpperCase() + apellido.slice(1);

    return {
        username: username,
        password: COMMON_PASSWORD,
        role: 'user', // Todos como usuarios normales
        isVerified: Math.random() > 0.95, // 5% de probabilidad de salir verificados
        isPremium: Math.random() > 0.90,  // 10% de probabilidad de tener Premium
        createdAt: Date.now(),
        bio: `¡Hola! Soy ${displayName} y me acabo de unir a Drama-X.`,
        avatarBase64: "", // Sin foto por defecto
        displayName: displayName,
        lastActive: Date.now()
    };
}

async function crearUsuariosMasivos() {
    console.log(`Iniciando la creación de ${USERS_TO_CREATE} usuarios...`);
    
    let creados = 0;
    
    // Firestore permite un máximo de 500 escrituras por cada "Batch" (Lote)
    const TAMANO_LOTE = 500;
    
    while (creados < USERS_TO_CREATE) {
        const batch = db.batch();
        const limiteActual = Math.min(TAMANO_LOTE, USERS_TO_CREATE - creados);
        
        for (let i = 0; i < limiteActual; i++) {
            const userData = generarUsuarioAleatorio();
            // Ruta exacta de Drama-X
            const userRef = db.collection('artifacts').doc(APP_ID)
                              .collection('public').doc('data')
                              .collection('users').doc(userData.username);
                              
            batch.set(userRef, userData);
        }
        
        try {
            await batch.commit();
            creados += limiteActual;
            console.log(`Progreso: ${creados} / ${USERS_TO_CREATE} usuarios creados en Firestore.`);
        } catch (error) {
            console.error("Error al subir un lote de usuarios:", error);
            break;
        }
    }
    
    console.log("¡Proceso terminado!");
}

// Ejecutar
crearUsuariosMasivos();